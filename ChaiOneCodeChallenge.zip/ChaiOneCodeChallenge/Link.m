//
//  Link.m
//  ChaiOneCodeChallenge
//
//  Created by Christopher Spence on 1/16/14.
//  Copyright (c) 2014 Christopher Spence. All rights reserved.
//

#import "Link.h"
#import "Entities.h"


@implementation Link

@dynamic length;
@dynamic position;
@dynamic text;
@dynamic url;
@dynamic entities;

@end
