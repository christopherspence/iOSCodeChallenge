//
//  Description.m
//  ChaiOneCodeChallenge
//
//  Created by Christopher Spence on 1/16/14.
//  Copyright (c) 2014 Christopher Spence. All rights reserved.
//

#import "Description.h"
#import "Entities.h"


@implementation Description

@dynamic html;
@dynamic text;
@dynamic entities;

@end
