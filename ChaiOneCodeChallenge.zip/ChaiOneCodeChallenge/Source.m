//
//  Source.m
//  ChaiOneCodeChallenge
//
//  Created by Christopher Spence on 1/16/14.
//  Copyright (c) 2014 Christopher Spence. All rights reserved.
//

#import "Source.h"
#import "Post.h"


@implementation Source

@dynamic clientId;
@dynamic link;
@dynamic name;
@dynamic post;

@end
