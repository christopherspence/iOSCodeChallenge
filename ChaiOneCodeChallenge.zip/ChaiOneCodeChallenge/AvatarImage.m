//
//  AvatarImage.m
//  ChaiOneCodeChallenge
//
//  Created by Christopher Spence on 1/16/14.
//  Copyright (c) 2014 Christopher Spence. All rights reserved.
//

#import "AvatarImage.h"
#import "User.h"


@implementation AvatarImage

@dynamic height;
@dynamic isDefault;
@dynamic url;
@dynamic width;
@dynamic user;

@end
