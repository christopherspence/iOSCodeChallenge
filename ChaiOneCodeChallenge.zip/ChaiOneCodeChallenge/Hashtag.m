//
//  Hashtag.m
//  ChaiOneCodeChallenge
//
//  Created by Christopher Spence on 1/16/14.
//  Copyright (c) 2014 Christopher Spence. All rights reserved.
//

#import "Hashtag.h"
#import "Entities.h"


@implementation Hashtag

@dynamic length;
@dynamic name;
@dynamic position;
@dynamic entities;

@end
