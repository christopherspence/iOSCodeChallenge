//
//  Counts.m
//  ChaiOneCodeChallenge
//
//  Created by Christopher Spence on 1/16/14.
//  Copyright (c) 2014 Christopher Spence. All rights reserved.
//

#import "Counts.h"
#import "User.h"


@implementation Counts

@dynamic followers;
@dynamic following;
@dynamic posts;
@dynamic stars;
@dynamic user;

@end
