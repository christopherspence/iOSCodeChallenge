//
//  Meta.m
//  ChaiOneCodeChallenge
//
//  Created by Christopher Spence on 1/16/14.
//  Copyright (c) 2014 Christopher Spence. All rights reserved.
//

#import "Meta.h"


@implementation Meta

@dynamic code;
@dynamic maxId;
@dynamic minId;
@dynamic more;

@end
