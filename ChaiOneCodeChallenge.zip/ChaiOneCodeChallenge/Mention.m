//
//  Mention.m
//  ChaiOneCodeChallenge
//
//  Created by Christopher Spence on 1/16/14.
//  Copyright (c) 2014 Christopher Spence. All rights reserved.
//

#import "Mention.h"
#import "Entities.h"


@implementation Mention

@dynamic id;
@dynamic isLeading;
@dynamic length;
@dynamic name;
@dynamic position;
@dynamic entities;

@end
